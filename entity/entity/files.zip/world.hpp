#pragma once
#include <tuple>
#include <vector>
#include <cstdint>
#include "entity.hpp"
#include "sparse_set.hpp"

namespace ecs {

// The component roster is fixed at compile time via the template pack.
// This is the trade for zero runtime type-erasure: no TypeId, no Any,
// no runtime registry. In exchange you get a closed, known set of columns.
template <typename... Components>
class World {
public:
    Entity spawn() {
        if (!free_list_.empty()) {
            const std::uint32_t idx = free_list_.back();
            free_list_.pop_back();
            return Entity{idx, generations_[idx]};
        }
        generations_.push_back(0);
        return Entity{static_cast<std::uint32_t>(generations_.size() - 1), 0};
    }

    void despawn(Entity e) {
        if (!alive(e)) return;
        (std::get<SparseSet<Components>>(pools_).erase(e), ...);
        generations_[e.index] += 1;
        free_list_.push_back(e.index);
    }

    [[nodiscard]] bool alive(Entity e) const noexcept {
        return e.index < generations_.size() && generations_[e.index] == e.generation;
    }

    template <typename C, typename... Args>
    C& insert(Entity e, Args&&... args) {
        return std::get<SparseSet<C>>(pools_).emplace(e, std::forward<Args>(args)...);
    }

    template <typename C>
    void remove(Entity e) { std::get<SparseSet<C>>(pools_).erase(e); }

    template <typename C>
    C* get(Entity e) { return std::get<SparseSet<C>>(pools_).get(e); }

    template <typename C>
    SparseSet<C>& pool() { return std::get<SparseSet<C>>(pools_); }

private:
    std::tuple<SparseSet<Components>...> pools_;
    std::vector<std::uint32_t> generations_;
    std::vector<std::uint32_t> free_list_;
};

} // namespace ecs
