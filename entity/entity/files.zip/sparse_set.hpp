#pragma once
#include <cstdint>
#include <vector>
#include <utility>
#include "entity.hpp"

namespace ecs {

// One of these per component type. Dense array is packed and cache-friendly
// to iterate; sparse array gives O(1) "does entity X have this component"
// and O(1) lookup. Swap-and-pop removal, so no shifting on erase.
template <typename Component>
class SparseSet {
public:
    static constexpr std::uint32_t tombstone = static_cast<std::uint32_t>(-1);

    template <typename... Args>
    Component& emplace(Entity e, Args&&... args) {
        if (e.index >= sparse_.size()) sparse_.resize(e.index + 1, tombstone);
        sparse_[e.index] = static_cast<std::uint32_t>(dense_entities_.size());
        dense_entities_.push_back(e);
        dense_components_.emplace_back(std::forward<Args>(args)...);
        return dense_components_.back();
    }

    void erase(Entity e) {
        if (!contains(e)) return;
        const std::uint32_t dense_idx = sparse_[e.index];
        const std::uint32_t last_idx  = static_cast<std::uint32_t>(dense_entities_.size() - 1);

        dense_entities_[dense_idx]   = dense_entities_[last_idx];
        dense_components_[dense_idx] = std::move(dense_components_[last_idx]);
        sparse_[dense_entities_[dense_idx].index] = dense_idx;

        dense_entities_.pop_back();
        dense_components_.pop_back();
        sparse_[e.index] = tombstone;
    }

    [[nodiscard]] bool contains(Entity e) const noexcept {
        return e.index < sparse_.size() && sparse_[e.index] != tombstone
            && dense_entities_[sparse_[e.index]] == e;
    }

    Component* get(Entity e) noexcept {
        return contains(e) ? &dense_components_[sparse_[e.index]] : nullptr;
    }

    // Direct access for the query iterator — kept package-private in spirit
    // (used only by World/Query, not meant as public entity-poking API).
    std::vector<Entity>&    dense_entities()   noexcept { return dense_entities_; }
    std::vector<Component>& dense_components() noexcept { return dense_components_; }

private:
    std::vector<std::uint32_t> sparse_;
    std::vector<Entity>        dense_entities_;
    std::vector<Component>     dense_components_;
};

} // namespace ecs
