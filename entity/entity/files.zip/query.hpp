#pragma once
#include <type_traits>
#include <algorithm>
#include "world.hpp"

namespace ecs {

template <typename T> struct strip_ref_const { using type = std::remove_const_t<std::remove_reference_t<T>>; };
template <typename T> using strip_ref_const_t = typename strip_ref_const<T>::type;

// Query<Position&, const Velocity&> over a specific WorldT. Mutable or
// read-only access is decided by whether you write `T&` or `const T&` in
// the parameter list. Iteration walks the smallest requested pool and
// filters against the rest, so a query over 3 components on a world with
// 10k entities but only 5 of that rarest component costs ~5 checks, not 10k.
template <typename WorldT, typename... Wants>
class Query {
public:
    explicit Query(WorldT& world) : world_(&world) {}

    template <typename F>
    void for_each(F&& f) {
        // Copy the driver pool's entity list: components may be inserted or
        // removed mid-iteration by the callback, which would otherwise
        // invalidate the vector we're walking (see caveats).
        auto snapshot = smallest_pool();
        for (Entity e : snapshot) {
            if ((world_->template pool<strip_ref_const_t<Wants>>().contains(e) && ...)) {
                f(fetch<Wants>(e)...);
            }
        }
    }

private:
    template <typename W>
    decltype(auto) fetch(Entity e) {
        using C = strip_ref_const_t<W>;
        return *world_->template pool<C>().get(e);
    }

    // Returns which component type currently has the fewest entities, so
    // for_each can drive iteration off the rarest pool instead of the
    // first-listed one. Comparing sizes needs no common return type, only
    // an index into the Wants pack — that's what sidesteps the "auto&
    // deduced differently per branch" problem entirely.
    template <typename Head, typename... Tail>
    std::size_t smallest_index() {
        std::size_t best_idx = 0;
        std::size_t best_size = world_->template pool<Head>().dense_entities().size();
        std::size_t i = 0;
        auto consider = [&](auto count) {
            ++i;
            if (count < best_size) { best_size = count; best_idx = i; }
        };
        (consider(world_->template pool<Tail>().dense_entities().size()), ...);
        return best_idx;
    }

    template <typename Head, typename... Tail>
    const std::vector<Entity>& smallest_pool_entities() {
        const std::size_t idx = smallest_index<Head, Tail...>();
        return pick_entities<0, Head, Tail...>(idx);
    }

    template <std::size_t I, typename Head, typename... Tail>
    const std::vector<Entity>& pick_entities(std::size_t idx) {
        if (I == idx) return world_->template pool<Head>().dense_entities();
        if constexpr (sizeof...(Tail) > 0) return pick_entities<I + 1, Tail...>(idx);
        else return world_->template pool<Head>().dense_entities(); // unreachable
    }

    const std::vector<Entity>& smallest_pool() {
        return unpack_smallest(std::tuple<strip_ref_const_t<Wants>...>{});
    }

    template <typename... Cs>
    const std::vector<Entity>& unpack_smallest(std::tuple<Cs...>) {
        return smallest_pool_entities<Cs...>();
    }

    WorldT* world_;
};

} // namespace ecs
