#include <cstdio>
#include <string_view>
#include "ecs/app.hpp"

// --- Components: just data. No methods, no base class, no concept to satisfy. ---
struct Position { float x = 0.f, y = 0.f; };
struct Velocity { float dx = 0.f, dy = 0.f; };
struct Sprite   { std::string_view resource; };

// --- Systems: free functions. Declare what you want via the Query type. ---
void movement_system(ecs::Query<ecs::App<Position, Velocity, Sprite>::WorldT, Position&, const Velocity&>& q) {
    q.for_each([](Position& pos, const Velocity& vel) {
        pos.x += vel.dx;
        pos.y += vel.dy;
    });
}

void render_system(ecs::Query<ecs::App<Position, Velocity, Sprite>::WorldT, const Position&, const Sprite&>& q) {
    q.for_each([](const Position& pos, const Sprite& spr) {
        std::printf("render %.*s at (%.1f, %.1f)\n",
                    static_cast<int>(spr.resource.size()), spr.resource.data(), pos.x, pos.y);
    });
}

int main() {
    ecs::App<Position, Velocity, Sprite> app;

    ecs::Entity player = app.spawn();
    app.insert<Position>(player, 0.f, 0.f);
    app.insert<Velocity>(player, 1.f, 0.f);
    app.insert<Sprite>(player, Sprite{"player.png"});

    ecs::Entity rock = app.spawn();
    app.insert<Position>(rock, 5.f, 5.f);
    app.insert<Sprite>(rock, Sprite{"rock.png"}); // no Velocity on purpose — should be skipped by movement_system

    app.add_system(movement_system);
    app.add_system(render_system);

    app.run(3); // three frames
}
