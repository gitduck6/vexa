#pragma once

namespace ecs {

// Extracts Arg from any callable shaped like void(Arg) or void(Arg&) —
// free function, function pointer, or captureless/capturing lambda.
// Systems only ever take exactly one parameter: a Query<...>.
template <typename T>
struct callable_traits : callable_traits<decltype(&T::operator())> {};

template <typename R, typename C, typename Arg>
struct callable_traits<R (C::*)(Arg) const> { using arg_type = Arg; };

template <typename R, typename C, typename Arg>
struct callable_traits<R (C::*)(Arg)> { using arg_type = Arg; };

template <typename R, typename Arg>
struct callable_traits<R (*)(Arg)> { using arg_type = Arg; };

template <typename R, typename Arg>
struct callable_traits<R (Arg)> { using arg_type = Arg; };

template <typename T>
using system_arg_t = typename callable_traits<T>::arg_type;

} // namespace ecs
