#pragma once
#include <cstdint>
#include <compare>

namespace ecs {

// An Entity IS NOT an object. It's a handle. No methods, no data beyond
// the id itself. This is the whole point of the Bevy model: entities don't
// know how to do anything, they're just a key you look components up with.
struct Entity {
    std::uint32_t index      = 0;
    std::uint32_t generation = 0;

    friend auto operator<=>(const Entity&, const Entity&) = default;
};

} // namespace ecs
