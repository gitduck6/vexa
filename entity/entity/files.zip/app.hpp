#pragma once
#include <vector>
#include <functional>
#include <type_traits>
#include "query.hpp"
#include "callable_traits.hpp"

namespace ecs {

// Systems are free functions (or lambdas) with exactly one parameter:
// a Query<Wants...>&. You never construct that Query yourself — App
// reads it out of the function's signature via system_arg_t and builds
// it for you before calling. That's the whole "just write a function,
// the wiring is automatic" feel, done with compile-time trait deduction
// instead of Bevy's runtime signature reflection.
template <typename... Components>
class App {
public:
    using WorldT = World<Components...>;

    template <typename Fn>
    App& add_system(Fn fn) {
        using QueryArg = std::remove_reference_t<system_arg_t<Fn>>;
        systems_.push_back([fn](WorldT& w) mutable {
            QueryArg q(w);
            fn(q);
        });
        return *this;
    }

    Entity spawn() { return world_.spawn(); }
    void despawn(Entity e) { world_.despawn(e); }

    template <typename C, typename... Args>
    C& insert(Entity e, Args&&... args) {
        return world_.template insert<C>(e, std::forward<Args>(args)...);
    }

    WorldT& world() { return world_; }

    void run_once() {
        for (auto& sys : systems_) sys(world_);
    }

    // Deliberately explicit frame count — there's no windowing/clock layer
    // in this file. Monako's own loop should call run_once() per frame;
    // see caveats for why App doesn't own timing.
    void run(int frames = 1) {
        for (int i = 0; i < frames; ++i) run_once();
    }

private:
    WorldT world_;
    std::vector<std::function<void(WorldT&)>> systems_;
};

} // namespace ecs
